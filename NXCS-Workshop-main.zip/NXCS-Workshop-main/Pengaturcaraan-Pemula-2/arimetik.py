# Program Penjumlahan

a = int(input("Masukkan angka pertama: "))
b = int(input("Masukkan angka kedua: "))

print("Hasil penjumlahan:", a + b)

############################################################

# Program Pengurangan

a = int(input("Masukkan angka pertama: "))
b = int(input("Masukkan angka kedua: "))

print("Hasil pengurangan:", a - b)

############################################################

# Program Pendaraban

a = int(input("Masukkan angka pertama: "))
b = int(input("Masukkan angka kedua: "))

print("Hasil pendaraban:", a * b)

############################################################

# Program Pembagian Sederhana

a = int(input("Masukkan angka pertama: "))
b = int(input("Masukkan angka kedua: "))

print("Hasil pembagian:", a / b)


############################################################

# Program Modulus

a = int(input("Masukkan angka pertama: "))
b = int(input("Masukkan angka kedua: "))

print("Hasil modulus:", a % b)
