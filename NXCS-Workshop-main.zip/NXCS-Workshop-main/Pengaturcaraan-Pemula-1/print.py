print("Selamat Datang ke Dunia Python!")
