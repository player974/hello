print("Hello, Dunia!")
